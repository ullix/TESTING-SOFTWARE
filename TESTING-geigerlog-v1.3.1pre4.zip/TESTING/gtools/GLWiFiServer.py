#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
GLWifiServer - A Python webserver running as a GeigerLog WiFiServer device
               enabling various external devices to send data by WiFi.
               Supported hardware devices:    GMC counter         via GMC
                                              CAJOE counter       via Pulse
                                              I2C Sensors         via I2C
               Only one at a time can be run.

               Runs on Python 3. Tested on Python 3.5 ... 3.10

Start with: path/to/GLWifiServer.py < GMC | Pulse | I2C >
Stop  with: CTRL-C
"""

###############################################################################
#    This file is part of GeigerLog.
#
#    GeigerLog is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    GeigerLog is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with GeigerLog.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################


###############################################################################
####################       CUSTOMIZE HERE        ##############################
###############################################################################
# Lines with '#' as first sign are comments and will be ignored
#
## Port Number
#  On which Port number shall the WiFiServer listen
#  NOTE: make sure, nothing else is using the port!
#        Use nmap to scan; available for Lin, Win, Mac, Raspi: https://nmap.org/
#        command is:   nmap  <IP of computer running GLWifiServer> -p1-65535
#              like:   nmap 10.0.0.100 -p1-65535
#
#  Options:      1024 ... 65535
#  Default     = 4000
WiFiServerPort = 4000

## Display name
#  Which Display name shall this WiFiServer use
#  Options:     < "any text" >
#  Default:    "GeigerLog WiFiServer"
DisplayName  = "GeigerLog WiFiServer"

# Filename of log file; change to your liking
# Logfile    = ""                   # if left empty a log file will NOT be written
Logfile      = "GLWifiServer.log"   # the log file will be in the directory
                                    # from where you started GLWifiServer

## GMC counter specific settings
#  If the GMC counter does not work properly with 'auto' settings, try defining
#  the settings manually:
GMCport      = "auto"               # on Raspi:    likely port is '/dev/ttyUSB0'
                                    # on Linux:    likely port is '/dev/ttyUSB0'
                                    # on Windows:  likely port is 'COM3'
GMCbaudrate  = "auto"               # baudrate;    for the GMC 300 series:    57600
                                    #              for 320, 5XX, 6XX series: 115200
GMCtimeout   = "auto"               # timeout in sec for the serial port; default is 3 sec


## I2C Sensor specific settings
#  The only supported I2C Sensor is LM75B (measures temperature).
#  Its I2Caddress can be adapted to non-default hardware.
I2Caddress   = 0x48                 # Options: 0x48 | 0x49 | 0x4A | 0x4B | 0x4C | 0x4D | 0x4E | 0x4F

## Pulse specific settings
#  Nothing to set

####################  END of user customization     ############################
################## NO USER CHANGES BELOW THIS LINE ! ###########################
################################################################################


import sys, os, io, time, datetime              # basic modules
import platform                                 # to find OS
import socket                                   # finding IP Adress
import http.server                              # web server
import urllib.parse                             # to parse queries
import threading                                # higher-level threading interfaces
import random                                   # to fudge some numbers
# import math                                     # needed for NAN testing

__author__              = "ullix"
__copyright__           = "Copyright 2016, 2017, 2018, 2019, 2020, 2021, 2022"
__credits__             = [""]
__license__             = "GPL3"
__version__             = 2.0                           # of this script
__script__              = os.path.basename(__file__)    # exclude the path, give just the filename


# colors for Linux terminal
TDEFAULT                = '\033[0m'             # default, i.e greyish
TYELLOW                 = '\033[93m'            # yellow
if "WINDOWS" in platform.platform().upper():    # Windows does not support terminal colors
    TDEFAULT            = ""
    TYELLOW             = ""

# Default settings
NAN                     = float('nan')          # 'not-a-number'; used as 'missing value'
debug                   = True                  #
verbose                 = False                 #
PrintIndent             = ""                    # indentation of log msg
xprintcounter           = 0                     # the count of dprint, vprint, wprint, xdprint commands

# GeigerLog's vars
VarNames                = ['CPM', 'CPS', 'CPM1st', 'CPS1st', 'CPM2nd', 'CPS2nd', 'CPM3rd', 'CPS3rd', 'Temp', 'Press', 'Humid', 'Xtra']

# WiFi Server
dogetmsg                = ""                    # web server msg
color                   = TDEFAULT              # used also as flag for color printout in Linux terminal
index                   = 0                     # number of WiFi calls
WiFiServer              = None                  # the HTTP Web server
WiFiServerThread        = None                  # thread handle
WiFiServerThreadStop    = None                  # flag to stop thread

# hardware
hardware                = None                  # can be "GMC", "Pulse", "I2C", set in main

# GMC specific
GMCser                  = None                  # handle
GMCbytes                = 0                     # 2 or 4 bytes returned on CPM*/CPS* calls; set in init

# Pulse specific
GPIO                    = None                  # handle

# I2C specific
i2c                     = None                  # handle
SensorRegister          = 0x00                  # is set in InitI2C


def stime():
    """Return current time as YYYY-MM-DD HH:MM:SS"""

    return longstime()[:-4]


def longstime():
    """Return current time as YYYY-MM-DD HH:MM:SS.mmm, (mmm = millisec)"""

    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] # ms resolution


def setIndent(arg):
    """increases or decreased the indent of prints"""

    global PrintIndent

    if arg > 0:  PrintIndent += "   "
    else:        PrintIndent  = PrintIndent[:-3]


def commonPrint(ptype, *args):
    """Printing function
    ptype : DEBUG, VERBOSE, werbose
    args  : anything to be printed
    return: nothing
    """

    global xprintcounter

    xprintcounter += 1

    tag = "{:23s} {:7s}: {:.>6d} ".format(longstime(), ptype, xprintcounter) + PrintIndent
    for arg in args: tag += str(arg)
    print(tag)


def dprint(*args):
    """Print args as single line"""

    if debug:   commonPrint("DEBUG", *args)


def vprint(*args):
    """Print args as single line"""

    if verbose: commonPrint("VERBOSE", *args)


def exceptPrint(e, srcinfo):
    """Print exception details (errmessage, file, line no)"""

    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname                     = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]    # which file?

    dprint("EXCEPTION: {} ({}), in file: {}, in line: {}".format(e, srcinfo, fname, exc_tb.tb_lineno))


def getMyIP():
    """get the IP of the computer running this program"""

    st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        st.connect(('10.255.255.255', 1))
        IP = st.getsockname()[0]
    except Exception as e:
        IP = '127.0.0.1'
        srcinfo = "Bad socket connect, IP:" + IP
        exceptPrint(fncname + str(e), srcinfo)
    finally:
        st.close()

    return IP


def initWiFiServer():
    """Initialize WiFiServer"""

    global WiFiServer, WiFiServerThread, WiFiServerThreadStop

    fncname = "initWiFiServer: "

    dprint(fncname)
    setIndent(1)

    # detect IP; use Port as set in header
    WiFiServerIP = getMyIP()

    # create the web server
    msg = "Ok"
    try:
        # 'ThreadingHTTPServer' vs. 'HTTPServer': no difference seen??
        # 'ThreadingHTTPServer': New in version Py 3.7. Do not use for compatibiliy with 3.6!!!
        # WiFiServer = http.server.ThreadingHTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer = http.server.HTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer.timeout = 5
        dprint(fncname + "HTTPServer started at: http://%s:%s" % (WiFiServerIP, WiFiServerPort))
    except Exception as e:
        msg = "WiFiServer could not be started. Is Port number already used?"
        exceptPrint(e, msg)

    WiFiServerThreadStop        = False
    WiFiServerThread            = threading.Thread(target = WiFiServerThreadTarget)
    WiFiServerThread.daemon     = True   # must come before daemon start: makes threads stop on exit!
    WiFiServerThread.start()

    setIndent(0)
    return msg


def WiFiServerThreadTarget():
    """Thread constantly triggers web readings"""

    fncname = "WiFiServerThreadTarget: "

    while not WiFiServerThreadStop:
        WiFiServer.handle_request()
        time.sleep(0.005)


def terminateWiFiServer():
    """stop and close Web server"""

    global WiFiServerThreadStop

    fncname = "terminateWiFiServer: "

    dprint(fncname)
    setIndent(1)

    WiFiServerThreadStop = True
    WiFiServer.server_close()

    dprint(fncname + "Done")
    setIndent(0)


class MyHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        """replacing the log_message function"""

        global dogetmsg, color

        # output:  ... LogMsg: GET /?ID=GeigerLog&M=10&S=11&M1=12&S1=13&M2=14&S2=15&M3=16&S3=17&T=18&P=19&H=20&X=21 HTTP/1.1, 302, -
        strarg = ", ".join(args)    # count(args) = 3 (except on errors)

        if color == TYELLOW:    dprint("WiFiServer LogMsg: ", strarg, dogetmsg)


class MyServer(MyHandler):

    def do_GET(self):
        """'do_GET' overwrites class function"""

        global dogetmsg, color

        fncname  = "WiFiServer do_GET: "
        dogetmsg = ""
        color    = TDEFAULT

        # dprint(fncname + "self.path: ", self.path)

        # if thread stopped this is the last dummy call to close the server
        if WiFiServerThreadStop:
            self.send_response(200)
            self.end_headers()
            dprint("WiFiServerThreadStop is True") # never reached?
            return


        # lastdata
        if   self.path.startswith("/GL/lastdata"):
            # CSV values of all 12 vars; like:
            # 6.500, 994.786, 997.429, 907.214, 983.857, 892.071, 154,  154,  2.08,  154, 0.9, 6.0
            bdata       = getDataCSV(1)  # for 1 sec = 1 single record

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # lastavg
        elif self.path.startswith("/GL/lastavg"):
            # same as lastdata
            DeltaT      = 1     # default
            query_components = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "chunk" in query_components: DeltaT = int(query_components["chunk"] [0])
            DeltaTsec   = DeltaT * 60                        # DeltaT is in minutes; but need sec
            DeltaTsec   = DeltaTsec if DeltaTsec > 0 else 1  # at least == 1
            # print("DeltaT, DeltaTsec", DeltaT, DeltaTsec)
            bdata       = getDataCSV(DeltaTsec)

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # id
        elif self.path == "/GL/id":
            answer      = "{} {}".format(DisplayName, __version__)
            bdata       = bytes(answer, "UTF-8")

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # favicon
        # elif self.path == '/GL/favicon.ico':
        elif "favicon.ico" in self.path:
            bdata       = b""                           # empty; no icon

            myheader    = "Content-type", "image/png"   # png image
            mybytes     = bdata
            myresponse  = 200

        # root
        elif self.path == '/GL/':
            answer      = "<!DOCTYPE html><style>html{text-align:center;</style><h1>Welcome to<br>WiFiServer</h1>"
            answer     += "<b>Supported Requests:</b><br>/id<br>/lastdata<br>/lastavg<br>"
            bdata       = bytes(answer, "UTF-8")

            myheader    = 'Content-Type', "text/html"  # HTML
            mybytes     = bdata
            myresponse  = 200

        # page not found 404 error
        else:
            # get calling system from self.headers["User-Agent"]:
            #   self.headers["User-Agent"] from Python:      BaseHTTP/0.6 Python/3.9.4
            #   self.headers["User-Agent"] from GMC counter: None
            #   self.headers["User-Agent"] from Firefox:     Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0
            #   self.headers["User-Agent"] from Chromium:    Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36
            # dprint("self.headers['User-Agent']: ", self.headers["User-Agent"])

            color    = TYELLOW
            if self.headers["User-Agent"] is None or "Python" in self.headers["User-Agent"]:
                answer   = "404 Page not found"
                myheader = 'Content-Type', "text/plain" # PLAIN

            else:
                answer   = "<!DOCTYPE html><style>html{text-align:center;</style><h1>404 Page not found</h1>"
                myheader = 'Content-Type', "text/html"  # HTML

            dogetmsg   = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

            mybytes    = bytes(answer, "UTF-8")
            myresponse = 404

        self.send_response(myresponse)
        self.send_header(*myheader)
        self.end_headers()

        try:    self.wfile.write(mybytes)
        except: pass

        # ~ dprint(fncname + self.path + " ", mybytes)


def getDataCSV(avg):
    """get the data as byte sequence in the form needed by GeigerLog
    avg   : The data as average over the last avg seconds; avg > 0
    return: data as a CSV list (as bytes): M, S, M1, S1, M2, S2, M3, S3, T, P, H, X
      like:                                b'1733.0,36.0,1884.7,30.2,34.0,34.2,34.0,0.0,34.0,32.3,32.0,2.0'
    """

    global index, hardware

    start  = time.time()

    fncname  = "getDataCSV: "
    index   += 1
    pdict    = {}

    if   hardware == "GMC":    pdict = {**pdict, **getDataGMC(avg)}
    elif hardware == "Pulse":  pdict = {**pdict, **getDataPulse(avg)}
    elif hardware == "I2C":    pdict = {**pdict, **getDataI2C(avg)}

    lastrec = ""
    for vname in VarNames:
        if vname in pdict:   value = pdict[vname]
        else:                value = NAN
        lastrec += "{:8.3f}, ".format(value)
    lastrec = lastrec[:-2]    # remove final ", "

    duration = 1000 * (time.time() - start) # ms
    appendLogfile("{:7d}, {:23s}, {}, {:8.3f}\n".format(index, longstime(), lastrec, duration))

    vprint("\nlastrec: ", lastrec)
    lastrec = lastrec.replace(" ", "")      # remove blanks

    return bytes(lastrec, "UTF-8")          # no comma at the end!


############################################################################
# Hardware functions for GMC devices  ######################################
############################################################################

def initGMC():

    global GMCser, GMCbytes, GMCport, GMCbaudrate, GMCtimeout

    try:
        # needed for GMC
        import serial                           # communication with serial port
        import serial.tools.list_ports          # allows listing of serial ports

    except ImportError as ie:
        msg  = "The module 'pyserial' was not found, but is required."
        exceptPrint(ie, msg)
        msg += "\nInstall with 'python -m pip install -U pyserial'."
        return msg

    except Exception as e:
        msg = str(e)
        exceptPrint(e, "")
        return msg

    fncname = "initGMC: "
    GMCcounterversion = "Undefined"

    # getting USB-to-Serial ports
    if GMCport != "auto":
        # GMCport was set manually; do not change

        pass
    else:
        # GMCport is "auto". Find the ports on this system
        dprint ("Searching for USB-to-Serial Ports - found on this system:")
        GMCports =  serial.tools.list_ports.comports()
        if len(GMCports) == 0:
            dprint("No USB-to-Serial Ports found on this system - Cannot run without one. Exiting.")
            return "Failure"

        # check for a GMC port with chip CH340
        foundport = False
        for port in GMCports :
            dprint ("   " + str(port))
            if  port.vid == 0x1a86 and port.pid == 0x7523:
                foundport = True
                GMCport = port.device
                break
        if not foundport:
            dprint("No GMC Ports found on this system - Cannot run without one. Exiting.")
            return "Failure"
    # dprint("   Selected Port: " + GMCport)
    print()


    # setting baudrate
    if GMCbaudrate != "auto":
        # GMCbaudrate was set manually; do not change
        pass
    else:
        # GMCbaudrate is "auto". Find the highest baudrate
        testbr = (115200, 57600)
        for br in testbr:
            try:
                testser = serial.Serial(GMCport, br, timeout=3)
                # print("testser: ", testser)
                bwrt = testser.write(b'<GETVER>>')
                trec = testser.read(14) # may leave bytes in the pipeline, if GETVER has
                                        # more than 14 bytes as may happen in newer counters
                # print("rec: ", rec)

                while True:
                    cnt = testser.in_waiting
                    if cnt == 0: break
                    trec += testser.read(cnt)
                    time.sleep(0.1)
                testser.close()
                # print("rec: ", rec)

                if trec.startswith(b"GMC"):
                    GMCbaudrate = br
                    # dprint("Baudrate: Success with {}".format(GMCbaudrate))
                    GMCcounterversion = trec.decode("UTF-8")
                    break

            except Exception as e:
                errmessage1 = fncname + "ERROR: Serial communication error on finding baudrate"
                exceptPrint(e, errmessage1)
                baudrate = None
                break

    # dprint("   Selected Baudrate: {}".format(GMCbaudrate))

    if GMCbaudrate == "auto":
        dprint("Could not establish communication with a counter. Is it connected? Will exit.")
        return "Failure"

    # timeout setting
    if GMCtimeout != "auto":
        # GMCtimeout was set manually; do not change
        pass
    else:
        # GMCtimeout is "auto". Set the timeout
        GMCtimeout = 3
    # dprint("   Selected Timeout: {}".format(GMCtimeout))


    # open the serial port with selected settings
    GMCser = serial.Serial(GMCport, GMCbaudrate, timeout=GMCtimeout)
    # dprint("GMCser: ", GMCser)

    if   "GMC-3"            in GMCcounterversion:   GMCbytes  = 2
    elif "GMC-500Re 1."     in GMCcounterversion:   GMCbytes  = 2    # perhaps Mike is only user
    elif "GMC-5"            in GMCcounterversion:   GMCbytes  = 4    # all 500+ and 510
    elif "GMC-6"            in GMCcounterversion:   GMCbytes  = 4    # all 500
    else:                                           GMCbytes  = 4    # everything else

    dprint("GMC Settings:")
    dprint("   {:27s} : {}".format("GMC Counter Version"         , GMCcounterversion))
    dprint("   {:27s} : {}".format("GMC Serial Port"             , GMCport))
    dprint("   {:27s} : {}".format("GMC Serial Baudrate"         , GMCbaudrate))
    dprint("   {:27s} : {}".format("GMC Serial Timeout (sec)"    , GMCtimeout))
    dprint("   {:27s} : {}".format("GMC Counter Byte Counts"     , GMCbytes))
    print()

    return "Ok"


def terminateGMC():
    """shuts down the counter"""

    fncname = "terminateGMC: "
    dprint(fncname)
    setIndent(1)

    if GMCser is not None:
        try:
            GMCser.close()
        except Exception as e:
            msg = "GMC Serial connection is not available"
            exceptPrint(e, msg)

    dprint(fncname + "Done")
    setIndent(0)


def getCPM():
    """the normal CPM call; might get CPM as sum of both tubes'"""

    return getGMC_Data(wcommand=b'<GETCPM>>', rlength=GMCbytes)


def getCPS():
    """the normal CPS call; might be the sum of High- and Low- sensitivity tube"""

    return getGMC_Data(wcommand=b'<GETCPS>>', rlength=GMCbytes, maskHighBit=True)


def getCPM1st():
    """get CPM from High Sensitivity tube; that should be the 'normal' tube"""

    return getGMC_Data(wcommand=b'<GETCPML>>', rlength=GMCbytes)


def getCPS1st():
    """get CPS from High Sensitivity tube; that should be the 'normal' tube"""

    return getGMC_Data(wcommand=b'<GETCPSL>>', rlength=GMCbytes, maskHighBit=True)


def getCPM2nd():
    """get CPM from Low Sensitivity tube; that should be the 2nd tube in the 500+"""

    return getGMC_Data(wcommand=b'<GETCPMH>>', rlength=GMCbytes)


def getCPS2nd():
    """get CPS from Low Sensitivity tube; that should be the 2nd tube in the 500+"""

    return getGMC_Data(wcommand=b'<GETCPSH>>', rlength=GMCbytes, maskHighBit=True)


def getGMC_Data(wcommand, rlength, maskHighBit=False):
    """Write to and read from device and convert to value; return value"""

    fncname = "getGMC_Data: "

    try:
        bwrt = GMCser.write(wcommand)  # returns bytes-written of type int
        srec = GMCser.read(rlength)    # returns srec of type bytes
        # dprint(fncname + "srec: ", srec)
    except Exception as e:
        exceptPrint(e, fncname)
        msg = "# EXCEPTION: " + fncname + str(e) + "\n"
        appendLogfile(msg)
        return NAN

    if len(srec) == GMCbytes:     # ok, got n bytes as expected
        if    GMCbytes == 4:
            value = ((srec[0]<< 8 | srec[1]) << 8 | srec[2]) << 8 | srec[3]
        elif  GMCbytes == 2:
            value = srec[0] << 8 | srec[1]
            if maskHighBit :    value = value & 0x3fff   # mask out high bits, as for CPS* calls on 300 series counters
        else:
            value = NAN         # should never happen

    else: # bytes missing or too many
        msg = "# ERROR in byte count, got {} bytes, expected {}!".format(len(srec), GMCbytes)
        dprint(msg)
        appendLogfile(msg + "\n")
        value = NAN

    vprint("   " + fncname, "wcommand:{:13s}, rlength:{:1d}, maskHighBit:{:5s}, srec:{:20s}, value:{:0.3f}".format(str(wcommand), rlength, str(maskHighBit), str(srec), value))

    return value


def handleGMCCollection():
    """nothing to do but wait"""

    while True: time.sleep(100)


def getDataGMC(avg):
    """get the data from GMC Geiger counter"""

    # NOTE: 'avg' is currently ignored; CPM is the minute sum of CPS anyway

    CPM    = getCPM()
    CPS    = getCPS()
    CPM1st = getCPM1st()
    CPS1st = getCPS1st()
    CPM2nd = getCPM2nd()
    CPS2nd = getCPS2nd()

    alldata = {"CPM": CPM, "CPS": CPS, "CPM1st": CPM1st, "CPS1st": CPS1st, "CPM2nd": CPM2nd, "CPS2nd": CPS2nd }

    return alldata

############################################################################
# End Hardware functions for GMC devices  ##################################
############################################################################


############################################################################
# Hardware functions for I2C Device ########################################
############################################################################

def initI2C():
    """Initialize I2C"""

    global i2c, SensorRegister, TempStore

    from collections import deque

    if is_raspberrypi():
        # I2C devices on Raspi
        try:
            import smbus

        except ImportError as ie:
            msg  = "The module 'smbus' was not found, but is required."
            exceptPrint(ie, msg)
            msg  = "\n\n" + msg + "\nOn Raspberry Pi install with: 'sudo apt install Python-smbus'."
            msg += "\nOn other computers install with 'python3 -m pip install -U smbus'."
            return msg

        except Exception as e:
            msg = str(e)
            exceptPrint(e, "")
            return msg

        # initialize I2C-Bus
        i2c = smbus.SMBus(1)

        I2Csensor  = "LM75B"        # there is no other option so far
        SensorRegister = 0x00
        msg = "Ok"

    else:
        # NOT on Raspi
        i2c = None
        dprint("This I2C script will work ONLY on a Raspi computer, but this is NOT a Raspi!")
        dprint("The program will continue, but you will get only random values around 50.")
        msg = "Ok"

    TempStore = deque([], 60) # space for 60 sec data

    return msg


def terminateI2C():
    """closes I2C"""

    fncname = "terminateI2C: "
    dprint(fncname)
    setIndent(1)

    if i2c is not None:
        try:
            i2c.close()
        except Exception as e:
            msg = "I2C connection is not available"
            exceptPrint(e, msg)

    dprint(fncname + "Done")
    setIndent(0)


def handleTempCollection():
    """Use an endless loop and simple timer to create 1 sec intervals for getting Temp"""

    global TempStore

    next = time.time() + 1                          # add 1 sec
    time.sleep(next - time.time() - 0.002)          # sleep until 2 ms before next cycle
    while True:
        # if debug: print(".", end="")
        if time.time() >= next:
            # if debug: print()
            TempStore.append(getTemp())             # advance the position for storing value, or shift left when full
            next = time.time() + 1                  # start a new  1 sec period
            # print("\n" + longstime(), "len:", len(PCounts), "PCounts:", PCounts)
            time.sleep(next - time.time() - 0.0015) # allow for some cycles in while loop


def getTemp():
    """get Temp from I2C connected LM75B"""

    # assumed is an LM75B with 11 bit resolution!
    # run time on Raspi: 3 ... 8 ms

# not running on the Raspi, just fudge some random numbers around 50
    if i2c is None:
        Temp = random.randint(47, 53)

# running on Raspi:
    else:
        start = time.time()
        try:
            raw = i2c.read_i2c_block_data(I2Caddress, SensorRegister)   # on Raspi takes 3 ... 8 ms
        except Exception as e:
            exceptPrint(e, "I2C Reading failed")
            return NAN
        stop = time.time()
        # dprint("i2c.read_i2c_block_data: {:0.5f} ms".format(1000 * (stop - start)))

        msb   = raw[0]
        lsb   = raw[1]
        temp1 = ((msb << 8 | lsb ) >> 5)        # assuming LM75B with 11bit Temp resolution
        if temp1 & 0x400: temp1 = temp1 - 0x800 # 0x400 == 0b0100 0000 0000, 0x800 == 0b1000 0000 0000
        Temp  = temp1 * 0.125                   # deg Celsius for LM75B

    return Temp


def getDataI2C(avg):
    """get the data from I2C; there is only a single Temp value"""

    # lastdata
    if avg == 1:
        alldata = {"Temp": getTemp()}

    # lastavg (1 min average)
    else:
        lenAT = len(TempStore)
        if lenAT == 0:
            AvgTemp = NAN

        else:
            AvgTemp = 0
            for i in range(lenAT): AvgTemp += TempStore[i]
            AvgTemp = AvgTemp / lenAT

        alldata = {"Temp": AvgTemp, "Press": getTemp()}
        # alldata = {"Temp": AvgTemp}

    return alldata

############################################################################
# End Hardware functions for I2C device  ###################################
############################################################################


############################################################################
# Hardware functions for Raspi Pulse Counter  ##############################
############################################################################

def initPulse():
    """Inititalize the pulse counter"""

    global PulseCounts, PCounts, GPIO

    from collections import deque

    fncname                 = "initPulse: "
    Pulse_counter_version   = "Undefined"     # not (yet) needed
    PulseCounts             = 0
    PCounts                 = deque([0], 60)  # single value, len=1, to allow CPS with space for 60 sec CPS data
    # print("PCounts: ", PCounts)

    if is_raspberrypi():
        try:
            import RPi.GPIO as GPIO

        except ImportError as ie:
            msg  = "The module 'RPi.GPIO' was not found but is required."
            msg += "\nInstall with: 'python3 -m pip install -U RPi.GPIO'"
            exceptPrint(ie, msg)
            return msg

        except Exception as e:
            msg = "Running 'Pulse' is possible ONLY on a Raspberry Pi"
            exceptPrint(e, msg)
            return msg

        GPIO.setmode(GPIO.BCM)  # using BCM mode; use GPIO.setmode(GPIO.BOARD) for boardpin usage
        bcmpin = 17             # bcmpin=17 is on boardpin=11
        GPIO.setup(bcmpin, GPIO.IN, pull_up_down = GPIO.PUD_UP)
        GPIO.add_event_detect(bcmpin, GPIO.FALLING, callback=incrementCounts)

    else:
        # not a Raspi
        GPIO = None             # needed in terminatePulse

    return "Ok"


def terminatePulse():
    """shuts down the pulse counter; cleanup is important!"""

    fncname = "terminatePulse: "
    dprint(fncname)
    setIndent(1)

    if GPIO is not None:
        try:
            GPIO.cleanup()
        except Exception as e:
            msg = "GPIO is not available"
            exceptPrint(e, msg)

    dprint(fncname + "Done")
    setIndent(0)


def handleCountCollection():
    """Use an endless loop and simple timer to create 1 sec intervals for getting CPS/CPM"""

    global PulseCounts

    PulseCounts = 0
    next        = time.time() + 1                   # add 1 sec
    time.sleep(next - time.time() - 0.002)          # sleep until 2 ms before next cycle
    while True:
        # if debug: print(".", end="")
        if time.time() >= next:
            # if debug: print()
            countSaver()                            # takes 0.003 ms on Desktop; 0.1 ... 0.2 ms on Raspi
            next = time.time() + 1                  # start a new  1 sec period
            # print("\n" + longstime(), "len:", len(PCounts), "PCounts:", PCounts)
            time.sleep(next - time.time() - 0.0011) # allow for some cycles in while loop. Desktop: 0.0011 ok


def incrementCounts(bcmpin):
    """increment Pulse counter"""

    global PulseCounts

    PulseCounts += 1
    # print("incrementCounts called, PulseCounts: ", PulseCounts)


def countSaver():
    """appends CPS to deque with maxlength=60; thus when full, deque shifts left"""

    # takes some 0.003 ... 0.008 ms on Desktop
    #            0.1   ... 0.2   ms on Raspberry Pi
    #
    # Delta time in countSaver typical values:
    # same on desktop and on Raspberry Pi
    #   Delta time in countSaver:  0.9999966621398926
    #   Delta time in countSaver:  1.000013828277588

    global PulseCounts, PCounts

    # Not running on Raspi; just fudge some random numbers around 100
    if GPIO is None: PulseCounts = random.randint(80, 120)  # 80 <=  value <= 120

    # running on Raspi
    PCounts.append(PulseCounts)    # append value, or shift left when deque full
    PulseCounts = 0


def getPulseCPS():
    """get CPS counts and return as value"""

    return PCounts[-1]


def getPulseCPM():
    """get CPM counts and return as value"""

    CPM = 0
    for i in range(len(PCounts)):
        CPM += PCounts[i]

    return CPM


def getDataPulse(avg):
    """get the data from Pulse"""
    # NOTE: 'avg' is currently ignored; CPM is the minute average of CPS anyway

    CPM    = getPulseCPM()
    CPS    = getPulseCPS()

    alldata = {"CPM": CPM, "CPS": CPS }
    # print("alldata: ", alldata)

    return alldata

############################################################################
# End Hardware functions for Raspi Pulse Counter  ##########################
############################################################################


def writeLogfile(msg):
    """Make new file, or empty old one, then write msg to file"""

    if Logfile == "": return # no writing if filename is empty

    with open(Logfile, 'w') as log:
        log.write(msg)


def appendLogfile(msg):
    """append msg to the end of file"""

    if Logfile == "": return # no writing if filename is empty

    with open(Logfile, 'a') as log:
        log.write(msg)


def is_raspberrypi():
    """check if it is a Raspberry Pi computer"""

    try:
        with io.open('/sys/firmware/devicetree/base/model', 'r') as m:
            if 'raspberry pi' in m.read().lower(): return True
    except Exception: pass
    return False


def main():

    global hardware

    # verify proper Python version
    if sys.version_info[0] != 3:
        print("This software requires Python Version 3.")
        print("Your Python version is Version {}.{}".format(sys.version_info[0], sys.version_info[1]))
        print("Cannot continue, will exit.")
        return

    # check for Raspi
    if is_raspberrypi():    computer = "Raspberry Pi"
    else:                   computer = "Unknown (not a Raspi)"

    # print system docu
    print("=" * 150)
    dprint("{:30s} : {}".format("Version of {}".format(__script__), __version__))
    dprint("{:30s} : {}".format("Operating System", platform.platform()))
    dprint("{:30s} : {}".format("Machine", platform.machine()))
    dprint("{:30s} : {}".format("Architecture", platform.architecture()[0]))
    dprint("{:30s} : {}".format("Computer", computer))
    dprint("{:30s} : {}".format("Version of Python", sys.version.split(" ")[0]))
    dprint("{:30s} : {}".format("Logfile", Logfile))
    dprint("{:30s} : {}".format("Supported Devices", "GMC, Pulse, I2C"))

    # set the hardware
    hardwareFail = False
    if len(sys.argv) > 1:
        # sys.argv[0] is progname
        if   sys.argv[1].strip().upper() == "GMC"   : hardware = "GMC"
        elif sys.argv[1].strip().upper() == "PULSE" : hardware = "Pulse"
        elif sys.argv[1].strip().upper() == "I2C"   : hardware = "I2C"
        else:
            dprint("Undefined hardware given on command line")
            hardwareFail = True
    else:
        dprint("No hardware given on command line")
        hardwareFail = True

    if hardwareFail:
        dprint("Start with either: 'GLWifiServer GMC' or 'GLWifiServer Pulse' or 'GLWifiServer I2C'")
        return
    else:
        dprint("{:30s} : {}".format("Selected Device ", hardware))
    print()

    # init the hardware
    hardwareresponse = "Undefined"
    if   hardware == "GMC":     hardwareresponse = initGMC()
    elif hardware == "Pulse":   hardwareresponse = initPulse()
    elif hardware == "I2C":     hardwareresponse = initI2C()
    if hardwareresponse == "Ok":
        dprint("Init {} device: {}".format(hardware, hardwareresponse))
    else:
        dprint("Init {} device FAILED: {}".format(hardware, hardwareresponse))
        return

    # init the WiFi Server
    WSresponse = initWiFiServer()
    if WSresponse == "Ok":
        dprint("Init WiFi Server: ", WSresponse)
    else:
        dprint("Init WiFi Server FAILED: ", WSresponse)
        return

    # begin logfile
    msg  = "# Log file created with: '{}', Version: {}\n".format(__script__, __version__)
    msg += "# Python Version:   {}\n".format(sys.version.replace('\n', ""))
    msg += "# Operating System: {}\n".format(platform.platform())
    msg += "# Machine, Arch:    {}, {}\n".format(platform.machine(), platform.architecture()[0])
    msg += "# Computer:         {}\n".format(computer)
    msg += "# Selected Device:  {}\n".format(hardware)
    msg += "# Index,                DateTime,      CPM,      CPS,   CPM1st,   CPS1st,   CPM2nd,   CPS2nd,   CPM3rd,   CPS3rd,     Temp,    Press,    Humid,     Xtra,   Duration[ms]\n"
    writeLogfile(msg)
    if Logfile > "": dprint("Init Logfile '{}'".format(Logfile))
    else:            dprint("Logfile will NOT be written")
    print()

    # Loop until CTRL-C
    try:
        if   hardware == "GMC":     handleGMCCollection()
        elif hardware == "Pulse":   handleCountCollection()
        elif hardware == "I2C":     handleTempCollection()

    except KeyboardInterrupt:
        print()
        terminateWiFiServer()
        if   hardware == "GMC":     terminateGMC()
        elif hardware == "Pulse":   terminatePulse()
        elif hardware == "I2C":     terminateI2C()

        dprint("Exiting {}".format(__script__))


if __name__ == '__main__':
    main()
    print()
