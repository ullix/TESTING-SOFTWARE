#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
DEMO_WiFiServer - A Python webserver running as a GeigerLog WiFiServer device

Start with: path/to/DEMO_WiFiServer.py
Stop  with: CTRL-C
"""

###############################################################################
#    This file is part of GeigerLog.
#
#    GeigerLog is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    GeigerLog is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with GeigerLog.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################

__author__          = "ullix"
__copyright__       = "Copyright 2016, 2017, 2018, 2019, 2020, 2021, 2022"
__credits__         = [""]
__license__         = "GPL3"
__version__         = 1.0       # of DEMO_WiFiServer


################################################################################
###################  User configurable items ###################################
##
## Port Number
##  Set the Port number, on which the WiFiServer will listen
##  Allowed values: 1024 ... 65535
##  Default = 8000
#
# WiFiServerPort = 8000
WiFiServerPort   = 8007
##
##  Display name of this WiFiServer device
##   Allowed: any text
##   Default: DEMO WiFiServer
DisplayName = "DEMO WiFiServer"
##
################################################################################


import sys, os, io, time, datetime  # basic modules
import platform                     # to find OS
import socket                       # finding IP Adress
import http.server                  # web server
import urllib.parse                 # to parse queries
import threading                    # higher-level threading interfaces
import math                         # needed for sqrt, log, cos, pi
import random                       # for Demo values

# colors for Linux terminal
TDEFAULT                = '\033[0m'             # default, i.e greyish
TYELLOW                 = '\033[93m'            # yellow
if "WINDOWS" in platform.platform().upper():    # Windows does not support terminal colors
    TDEFAULT            = ""
    TYELLOW             = ""

NAN                     = float('nan')          # 'not-a-number'; used as 'missing value'
debugIndent             = ""
xprintcounter           = 0                     # the count of dprint, vprint, wprint, xdprint commands

dogetmsg                = ""                    # dummy
color                   = TDEFAULT

WiFiServer              = None                  # the HTTP server
WiFiServerThread        = None                  # thread handling
WiFiServerThreadStop    = None                  # thread handling

WiFiServerIP            = None                  # Do not change; will be auto detected


def stime():
    """Return current time as YYYY-MM-DD HH:MM:SS"""

    return longstime()[:-4]


def longstime():
    """Return current time as YYYY-MM-DD HH:MM:SS.mmm, (mmm = millisec)"""

    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] # ms resolution


def setIndent(arg):
    """increases or decreased the indent of prints"""

    global debugIndent

    if arg > 0:  debugIndent += "   "
    else:        debugIndent  = debugIndent[:-3]


def commonPrint(ptype, *args):
    """Printing function
    ptype : DEBUG, VERBOSE, werbose
    args  : anything to be printed
    return: nothing
    """

    global xprintcounter

    xprintcounter += 1
    tag                   = "{:23s} {:7s}: {:.>6d} ".format(longstime(), ptype, xprintcounter) + debugIndent
    for arg in args: tag += str(arg)

    print(tag)


def dprint(*args):
    """Print args as single line"""

    commonPrint("DEBUG", *args)


def exceptPrint(e, srcinfo):
    """Print exception details (errmessage, file, line no)"""

    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname                     = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]    # which file?

    dprint("EXCEPTION: {} ({}), in file: {}, in line: {}".format(e, srcinfo, fname, exc_tb.tb_lineno))


def getMyIP():
    """get the IP of the computer running this program"""

    st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        st.connect(('10.255.255.255', 1))
        IP = st.getsockname()[0]
    except Exception as e:
        IP = '127.0.0.1'
        srcinfo = "Bad socket connect, IP:" + IP
        exceptPrint(fncname + str(e), srcinfo)
    finally:
        st.close()

    return IP


def initWiFiServer():
    """Initialize WiFiServer"""

    global WiFiServer, WiFiServerThread, WiFiServerThreadStop

    fncname = "initWiFiServer: "

    dprint(fncname)
    setIndent(1)

    # detect IP; use Port as set in header
    WiFiServerIP = getMyIP()

    # create the web server
    msg = "ok"
    try:
        # 'ThreadingHTTPServer' vs. 'HTTPServer': no difference seen??
        # WiFiServer = http.server.ThreadingHTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer = http.server.HTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer.timeout = 5
        dprint(fncname + "HTTPServer started at: http://%s:%s" % (WiFiServerIP, WiFiServerPort))
    except Exception as e:
        msg = "WiFiServer could not be started. Is Port number already used?"
        exceptPrint(e, msg)

    WiFiServerThreadStop        = False
    WiFiServerThread            = threading.Thread(target = WiFiServerThreadTarget)
    WiFiServerThread.daemon     = True        # daemons will be stopped on exit!
    WiFiServerThread.start()

    setIndent(0)
    return msg


def WiFiServerThreadTarget():
    """Thread that constantly triggers readings from the device."""

    fncname = "WiFiServerThreadTarget: "

    # equiv to : WiFiServer.serve_forever()
    # to end, a final call from a client is needed !!!
    while not WiFiServerThreadStop:
        WiFiServer.handle_request()
        time.sleep(0.005)


def terminateWiFiServer():
    """close threads and shut down"""

    """
    NOTE: for thread stopping see:
    https://www.geeksforgeeks.org/python-different-ways-to-kill-a-thread/
    damons will be stopped on exit!
    Using a hidden function _stop() : (note the underscore!)
    function _stop not working in Py3.9.4:
    WiFiServerThread._stop() --> results in: AssertionError
    """

    global WiFiServerThread, WiFiServerThreadStop

    start   = time.time()
    fncname = "terminateWiFiServer: "

    dprint(fncname)
    setIndent(1)

    WiFiServerThreadStop = True

    # dummy call to satisfy one last WiFiServer.handle_request()
    # gglobs.WiFiClientPort = 8080
    # myurl = "http://{}:{}/?AID=HabeFertig".format(WiFiServerIP, WiFiServerPort)
    # try:
    #     with urllib.request.urlopen(myurl, timeout=10) as response:
    #         answer = response.read()
    #     filler = " ..." if len(answer) > 100 else ""
    #     dprint("Server Response: ", answer[:100], filler)
    # except Exception as e:
    #     srcinfo = "Bad URL: " + myurl
    #     exceptPrint(fncname + str(e), srcinfo)


    # "This blocks the calling thread until the thread
    #  whose join() method is called is terminated."
    WiFiServerThread.join(3)

    # verify that thread has ended, but wait not longer
    # than 5 sec (takes 0.006...0.016 ms)
    startwait = time.time()
    while (time.time() - startwait) < 5:
        isAlive = WiFiServerThread.is_alive()
        msg     = "Yes" if isAlive else "No"
        if not isAlive: break
    dprint(fncname + "thread-status: is_alive: {}".format(msg))

    WiFiServer.server_close()

    dprint(fncname + "Terminated in {:0.1f} ms".format(1000 * (time.time() - start)))
    setIndent(0)


class MyHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        """replacing the log_message function"""

        global dogetmsg, color

        # output:  ... LogMsg: GET /?ID=GeigerLog&M=10&S=11&M1=12&S1=13&M2=14&S2=15&M3=16&S3=17&T=18&P=19&H=20&X=21 HTTP/1.1, 302, -
        strarg = ", ".join(args)    # count(args) = 3 (except on errors)

        if color == TYELLOW:    dprint("WiFiServer LogMsg: ", strarg, dogetmsg)


class MyServer(MyHandler):

    # get calling system from self.headers["User-Agent"]:
    #   self.headers["User-Agent"] from Python:      BaseHTTP/0.6 Python/3.9.4
    #   self.headers["User-Agent"] from GMC counter: None
    #   self.headers["User-Agent"] from Firefox:     Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0
    #   self.headers["User-Agent"] from Chromium:    Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36

    def do_GET(self):
        """'do_GET' overwrites class function"""

        global dogetmsg, color

        fncname  = "WiFiServer do_GET: "
        dogetmsg = ""
        color    = TDEFAULT

        # if thread stopped this is the last dummy call to close the server
        if WiFiServerThreadStop:
            self.send_response(200)
            self.end_headers()
            dprint("WiFiServerThreadStop is True") # never reached?
            return


        # lastdata
        if   self.path.startswith("/lastdata"):
            # Datetime plus values of all 12 vars; format like:
            # 2021-10-08 10:01:41, 6.500, 994.786, 997.429, 907.214, 983.857, 892.071, 154,  154,  2.08,  154, 0.9, 6.0
            bdata       = getDataCSV(1)  # for 1 sec = 1 single record

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # lastavg
        elif self.path.startswith("/lastavg"):
            # Datetime plus values of all 12 vars, averaged over chunk minutes; format like: see lastdata
            DeltaT      = 1     # default
            query_components = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "chunk" in query_components: DeltaT = int(query_components["chunk"] [0])
            DeltaTsec   = DeltaT * 60                        # DeltaT is in minutes; but need sec
            DeltaTsec   = DeltaTsec if DeltaTsec > 0 else 1  # at least == 1
            # print("DeltaT, DeltaTsec", DeltaT, DeltaTsec)
            bdata       = getDataCSV(DeltaTsec)

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # id
        elif self.path == "/id":
            answer      = "{} {}".format(DisplayName, __version__)
            bdata       = bytes(answer, "UTF-8")

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # favicon
        elif self.path == '/favicon.ico':
            bdata       = b""                           # empty; no icon

            myheader    = "Content-type", "image/png"   # png image
            mybytes     = bdata
            myresponse  = 200

        # root
        elif self.path == '/':
            answer      = "<!DOCTYPE html><style>html{text-align:center;</style><h1>Welcome to<br>WiFiServer</h1>"
            answer     += "<b>Supported Requests:</b><br>/id<br>/lastdata<br>/lastavg<br>"
            bdata       = bytes(answer, "UTF-8")

            myheader    = 'Content-Type', "text/html"  # HTML
            mybytes     = bdata
            myresponse  = 200

            dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

        # page not found 404 error
        else:
            # dprint("self.headers['User-Agent']: ", self.headers["User-Agent"])
            color    = TYELLOW
            if self.headers["User-Agent"] is None or "Python" in self.headers["User-Agent"]:
                answer   = "404 Page not found"
                myheader = 'Content-Type', "text/plain" # PLAIN
                dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

            else:
                answer   = "<!DOCTYPE html><style>html{text-align:center;</style><h1>404 Page not found</h1>"
                myheader = 'Content-Type', "text/html"  # HTML
                dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

            mybytes    = bytes(answer, "UTF-8")
            myresponse = 404

        self.send_response(myresponse)
        self.send_header(*myheader)
        self.end_headers()

        try:    self.wfile.write(mybytes)
        except: pass

        dprint(fncname + self.path + " ", mybytes)


def getDataCSV(avg):
    """returns data as a CSV list as bytes,
    like: b'2021-10-25 11:26:33,1733.0,36.0,1884.7,30.2,34.0,34.2,34.0,0.0,34.0,32.3,32.0,2.0
    avg :   The data as average over the last avg seconds; avg > 0
    """

    fncname = "getDataCSV: "

    #
    # --------------- This is a SIMULATION only ----------------------------
    #            Replace with your own data handling
    #
    # the GeigerLog configuration file sets these defaults:
    # Option auto defaults to 'CPM, CPS, Temp, Press, Humid'
    #
    # Demo data are created as random Normal or random Pseudo-Poisson values.

    # local functions ######################################################
    def getNormal(av, sd, N):
        """Python's Normal distribution; take average of N values"""

        sum = 0
        for i in range(0, N):
            sum += random.normalvariate(av, sd)                 # random.normalvariate(mu, sigma)

        return sum / N


    def getPseudoPoisson(av, N):
        """getting PseudoPoisson from Normal by setting all negative values to zero;
        take average ov N values;
        best used with av >= 10"""

        sum = 0
        for i in range(0, N):
            val = random.normalvariate(av, math.sqrt(av))      # random.normalvariate(mu, sigma)
            sum += val if val >= 0 else 0

        return sum / N

    # end local functions ##################################################

    N      = avg if avg > 0 else 1                             # at least N == 1

    CPM    = getPseudoPoisson(18,       N)
    CPS    = getPseudoPoisson(0.3,      N)
    CPM1st = getPseudoPoisson(100,      N)
    CPS1st = getPseudoPoisson(1.7,      N)
    CPM2nd = getPseudoPoisson(1000,     N)
    CPS2nd = getPseudoPoisson(16.7,     N)
    CPM3rd = getPseudoPoisson(10000,    N)
    CPS3rd = getPseudoPoisson(167,      N)
    T      = getNormal(  25,  2,        N)
    P      = getNormal(1000, 20,        N)
    H      = getNormal(  50, 30,        N)
    X      = getNormal( 600, 50,        N)

    lastrec = "{:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}".format(
                CPM, CPS,
                CPM1st, CPS1st,
                CPM2nd, CPS2nd,
                CPM3rd, CPS3rd,
                T, P, H, X
            )

    # -- end simulation -----------------------------------------------------

    return bytes(lastrec, "UTF-8") # no comma at the end!


if __name__ == '__main__':
    dprint("   Init: ", initWiFiServer())
    try:
        while True: time.sleep(100)
    except KeyboardInterrupt:
        print()
        terminateWiFiServer()
        dprint("Exiting WiFiServer")

    print()

