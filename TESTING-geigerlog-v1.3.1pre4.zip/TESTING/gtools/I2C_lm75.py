#! /usr/bin/python3
# -*- coding: utf-8 -*-

import smbus, time

I2C_TMP_LM75_ADRESS = 0x48              # I2C-Adresse des LM75 Temperatursensors (0x48)
LM75_TMP_BYTE       = 0x00              # Adresse im LM75, ab der Daten ausgelesen werden
i2c                 = smbus.SMBus(1)    # initialize I2C-Bus

def getTempB():
    """get Temp from I2C connected LM75B"""

    raw = i2c.read_i2c_block_data(I2C_TMP_LM75_ADRESS, LM75_TMP_BYTE)

    msb = raw[0]
    lsb = raw[1]
    temp1 = ((msb << 8 | lsb ) >> 5)
    if temp1 & 0x400:               # 0x400 == 0b0100 0000 0000
        temp1 = temp1 - 0x800       # 0x800 == 0b1000 0000 0000
    Temp  = temp1 * 0.125           # deg Celsius for LM75B (11bit)

    return Temp


if __name__ == '__main__':
    while True:
        print("LM75B-Temperatur: "+ str(getTempB()) + " °C")
        time.sleep(1)

