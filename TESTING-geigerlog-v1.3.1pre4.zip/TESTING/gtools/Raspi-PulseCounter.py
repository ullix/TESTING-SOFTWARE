#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
Raspi-PulseCounter.py - Using Raspi to count pulse on the GPIO

"""
import RPi.GPIO as GPIO
from time import sleep
bcmpin = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(bcmpin, GPIO.IN, pull_up_down = GPIO.PUD_UP)

revcount = 0
def increaserev(channel):
    global revcount
    revcount += 1

GPIO.add_event_detect(bcmpin, GPIO.FALLING, callback=increaserev)

while True:
    sleep(1)
    print("RPM is {}".format(revcount))
    revcount = 0

