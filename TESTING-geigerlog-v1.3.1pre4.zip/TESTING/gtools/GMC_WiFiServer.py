#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
GMC_WiFiServer - A Python webserver running as a GeigerLog WiFiServer device
                 enabling GMC counter devices to send data by WiFi

Start with: path/to/GMC_WiFiServer.py
Stop  with: CTRL-C
"""

###############################################################################
#    This file is part of GeigerLog.
#
#    GeigerLog is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    GeigerLog is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with GeigerLog.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################

###############################################################################
####################       CUSTOMIZE HERE        ##############################
###############################################################################
# Lines with '#' as first sign are comments and will be ignored
#
## Port Number
#  On which Port number shall the WiFiServer listen; allowed: 1024 ... 65535
#  NOTE: make sure, nothing else is using the port!
#        Use nmap to scan; available for Lin, Win, Mac:  https://nmap.org/
#        command is:   nmap  <your computer's IP> -p1-65535
#
#  Default     = 4000
#
WiFiServerPort = 4000

## Display name
#  Which Display name shall this WiFiServer use; allowed: any text
#  Default: GMC WiFiServer
DisplayName  = "GMC WiFiServer"

## GMC counter specific definitions
#  If the GMC counter does not work properly with 'auto' settings, you should
#  define the settings manually:
GMCport      = "auto"               # on Raspi:    likely port is '/dev/ttyUSB0'
                                    # on Linux:    likely port is '/dev/ttyUSB0'
                                    # on Windows:  likely port is 'COM3'
GMCbaudrate  = "auto"               # baudrate;    for the GMC 300 series:    57600
                                    #              for 320, 5XX, 6XX series: 115200
GMCtimeout   = "auto"               # timeout in sec for the serial port; default is 3 sec
GMClogfile   = "GMC_WiFiServer.log" # filename for the log file; change to your liking
                                    # leave empty, like: "", if you do NOT want a log file

####################  END of user customization     ############################


################################################################################
######## NO USER CHANGES BELOW THIS LINE ! #####################################
################################################################################

__author__              = "ullix"
__copyright__           = "Copyright 2016, 2017, 2018, 2019, 2020, 2021, 2022"
__credits__             = [""]
__license__             = "GPL3"
__version__             = 1.0                   # of this script
__script__              = ""                    # will be set in main

import sys, os, io, time, datetime              # basic modules
import platform                                 # to find OS
import socket                                   # finding IP Adress
import http.server                              # web server
import urllib.parse                             # to parse queries
import threading                                # higher-level threading interfaces

# for GMC
import serial                                   # communication with serial port
import serial.tools.list_ports                  # allows listing of serial ports

# colors for Linux terminal
TDEFAULT                = '\033[0m'             # default, i.e greyish
TYELLOW                 = '\033[93m'            # yellow
if "WINDOWS" in platform.platform().upper():    # Windows does not support terminal colors
    TDEFAULT            = ""
    TYELLOW             = ""

# Default settings
NAN                     = float('nan')          # 'not-a-number'; used as 'missing value'
debug                   = True #False           # set to True for testing
debugIndent             = ""
xprintcounter           = 0                     # the count of dprint, vprint, wprint, xdprint commands

dogetmsg                = ""                    # dummy
color                   = TDEFAULT

WiFiServer              = None                  # the HTTP server
WiFiServerThread        = None                  # thread handling
WiFiServerThreadStop    = None                  # thread handling

WiFiServerIP            = None                  # Do not change; will be auto detected

# hardware
hardware                = None                  # to be defined in main; so far only "GMC" and "Pulse"

# GMC specific
ser                     = None                  # handle for Serial
nbytes                  = 0                     # number of bytes returned on CPM*/CPS* calls (2 or 4)
index                   = 0                     # counts number of savings


def stime():
    """Return current time as YYYY-MM-DD HH:MM:SS"""

    return longstime()[:-4]


def longstime():
    """Return current time as YYYY-MM-DD HH:MM:SS.mmm, (mmm = millisec)"""

    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] # ms resolution


def setIndent(arg):
    """increases or decreased the indent of prints"""

    global debugIndent

    if arg > 0:  debugIndent += "   "
    else:        debugIndent  = debugIndent[:-3]


def commonPrint(ptype, *args):
    """Printing function
    ptype : DEBUG, VERBOSE, werbose
    args  : anything to be printed
    return: nothing
    """

    global xprintcounter

    xprintcounter += 1
    if debug:   tag = "{:23s} {:7s}: {:.>6d} ".format(longstime(), ptype, xprintcounter) + debugIndent
    else:       tag = debugIndent
    for arg in args: tag += str(arg)

    print(tag)


def dprint(*args):
    """Print args as single line"""

    commonPrint("DEBUG", *args)


def exceptPrint(e, srcinfo):
    """Print exception details (errmessage, file, line no)"""

    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname                     = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]    # which file?

    dprint("EXCEPTION: {} ({}), in file: {}, in line: {}".format(e, srcinfo, fname, exc_tb.tb_lineno))


def getMyIP():
    """get the IP of the computer running this program"""

    st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        st.connect(('10.255.255.255', 1))
        IP = st.getsockname()[0]
    except Exception as e:
        IP = '127.0.0.1'
        srcinfo = "Bad socket connect, IP:" + IP
        exceptPrint(fncname + str(e), srcinfo)
    finally:
        st.close()

    return IP


def initWiFiServer():
    """Initialize WiFiServer"""

    global WiFiServer, WiFiServerThread, WiFiServerThreadStop

    fncname = "initWiFiServer: "

    dprint(fncname)
    setIndent(1)

    # detect IP; use Port as set in header
    WiFiServerIP = getMyIP()

    # create the web server
    msg = "Ok"
    try:
        # 'ThreadingHTTPServer' vs. 'HTTPServer': no difference seen??
        # WiFiServer = http.server.ThreadingHTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer = http.server.HTTPServer((WiFiServerIP, WiFiServerPort), MyServer)
        WiFiServer.timeout = 5
        dprint(fncname + "HTTPServer started at: http://%s:%s" % (WiFiServerIP, WiFiServerPort))
    except Exception as e:
        msg = "WiFiServer could not be started. Is Port number already used?"
        exceptPrint(e, msg)

    WiFiServerThreadStop        = False
    WiFiServerThread            = threading.Thread(target = WiFiServerThreadTarget)
    WiFiServerThread.daemon     = True        # daemons will be stopped on exit!
    WiFiServerThread.start()

    setIndent(0)
    return msg


def WiFiServerThreadTarget():
    """Thread that constantly triggers readings from the device."""

    fncname = "WiFiServerThreadTarget: "

    # equiv to : WiFiServer.serve_forever()
    # to end, a final call from a client is needed !!!
    while not WiFiServerThreadStop:
        WiFiServer.handle_request()
        time.sleep(0.005)


def terminateWiFiServer():
    """close threads and shut down"""

    """
    NOTE: for thread stopping see:
    https://www.geeksforgeeks.org/python-different-ways-to-kill-a-thread/
    damons will be stopped on exit!
    Using a hidden function _stop() : (note the underscore!)
    function _stop not working in Py3.9.4:
    WiFiServerThread._stop() --> results in: AssertionError
    """

    global WiFiServerThread, WiFiServerThreadStop

    start   = time.time()
    fncname = "terminateWiFiServer: "

    dprint(fncname)
    setIndent(1)

    WiFiServerThreadStop = True

    # dummy call to satisfy one last WiFiServer.handle_request()
    # gglobs.WiFiClientPort = 8080
    # myurl = "http://{}:{}/?AID=HabeFertig".format(WiFiServerIP, WiFiServerPort)
    # try:
    #     with urllib.request.urlopen(myurl, timeout=10) as response:
    #         answer = response.read()
    #     filler = " ..." if len(answer) > 100 else ""
    #     dprint("Server Response: ", answer[:100], filler)
    # except Exception as e:
    #     srcinfo = "Bad URL: " + myurl
    #     exceptPrint(fncname + str(e), srcinfo)


    # "This blocks the calling thread until the thread
    #  whose join() method is called is terminated."
    WiFiServerThread.join(3)

    # verify that thread has ended, but wait not longer
    # than 5 sec (takes <0.02 ms)
    startwait = time.time()
    while (time.time() - startwait) < 5:
        isAlive = WiFiServerThread.is_alive()
        msg     = "Yes" if isAlive else "No"
        if not isAlive: break
    dprint(fncname + "thread-status: is_alive: {}".format(msg))

    WiFiServer.server_close()

    dprint(fncname + "Terminated in {:0.1f} ms".format(1000 * (time.time() - start)))
    setIndent(0)


class MyHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        """replacing the log_message function"""

        global dogetmsg, color

        # output:  ... LogMsg: GET /?ID=GeigerLog&M=10&S=11&M1=12&S1=13&M2=14&S2=15&M3=16&S3=17&T=18&P=19&H=20&X=21 HTTP/1.1, 302, -
        strarg = ", ".join(args)    # count(args) = 3 (except on errors)

        if color == TYELLOW:    dprint("WiFiServer LogMsg: ", strarg, dogetmsg)


class MyServer(MyHandler):

    # get calling system from self.headers["User-Agent"]:
    #   self.headers["User-Agent"] from Python:      BaseHTTP/0.6 Python/3.9.4
    #   self.headers["User-Agent"] from GMC counter: None
    #   self.headers["User-Agent"] from Firefox:     Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0
    #   self.headers["User-Agent"] from Chromium:    Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36

    def do_GET(self):
        """'do_GET' overwrites class function"""

        global dogetmsg, color

        fncname  = "WiFiServer do_GET: "
        dogetmsg = ""
        color    = TDEFAULT

        # dprint(fncname + "self.path: ", self.path)

        # if thread stopped this is the last dummy call to close the server
        if WiFiServerThreadStop:
            self.send_response(200)
            self.end_headers()
            dprint("WiFiServerThreadStop is True") # never reached?
            return


        # lastdata
        if   self.path.startswith("/GMC/lastdata"):
            # Datetime plus values of all 12 vars; format like:
            # 2021-10-08 10:01:41, 6.500, 994.786, 997.429, 907.214, 983.857, 892.071, 154,  154,  2.08,  154, 0.9, 6.0
            bdata       = getDataCSV(1)  # for 1 sec = 1 single record

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # lastavg
        elif self.path.startswith("/GMC/lastavg"):
            # Datetime plus values of all 12 vars, averaged over chunk minutes; format like: see lastdata
            DeltaT      = 1     # default
            query_components = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "chunk" in query_components: DeltaT = int(query_components["chunk"] [0])
            DeltaTsec   = DeltaT * 60                        # DeltaT is in minutes; but need sec
            DeltaTsec   = DeltaTsec if DeltaTsec > 0 else 1  # at least == 1
            # print("DeltaT, DeltaTsec", DeltaT, DeltaTsec)
            bdata       = getDataCSV(DeltaTsec)

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # id
        elif self.path == "/GMC/id":
            answer      = "{} {}".format(DisplayName, __version__)
            bdata       = bytes(answer, "UTF-8")

            myheader    = "Content-type", "text/plain; charset=utf-8"
            mybytes     = bdata
            myresponse  = 200

        # favicon
        elif self.path == '/GMC/favicon.ico':
            bdata       = b""                           # empty; no icon

            myheader    = "Content-type", "image/png"   # png image
            mybytes     = bdata
            myresponse  = 200

        # root
        elif self.path == '/GMC/':
            answer      = "<!DOCTYPE html><style>html{text-align:center;</style><h1>Welcome to<br>WiFiServer</h1>"
            answer     += "<b>Supported Requests:</b><br>/id<br>/lastdata<br>/lastavg<br>"
            bdata       = bytes(answer, "UTF-8")

            myheader    = 'Content-Type', "text/html"  # HTML
            mybytes     = bdata
            myresponse  = 200

            dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

        # page not found 404 error
        else:
            # dprint("self.headers['User-Agent']: ", self.headers["User-Agent"])
            color    = TYELLOW
            if self.headers["User-Agent"] is None or "Python" in self.headers["User-Agent"]:
                answer   = "404 Page not found"
                myheader = 'Content-Type', "text/plain" # PLAIN
                dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

            else:
                answer   = "<!DOCTYPE html><style>html{text-align:center;</style><h1>404 Page not found</h1>"
                myheader = 'Content-Type', "text/html"  # HTML
                dogetmsg = "{} | {}{} {}".format(color, fncname, answer, TDEFAULT)

            mybytes    = bytes(answer, "UTF-8")
            myresponse = 404

        self.send_response(myresponse)
        self.send_header(*myheader)
        self.end_headers()

        try:    self.wfile.write(mybytes)
        except: pass

        dprint(fncname + self.path + " ", mybytes)

def getDataCSV(avg):
    """make choice depending on hardware"""

    if   hardware == "GMC":     return getDataCSVGMC(avg)
    elif hardware == "Pulse":   return getDataCSVPulse(avg)


def getDataCSVGMC(avg):
    """returns data as a CSV list as bytes: M, S, M1, S1, M2, S2, M3, S3, T, P, H, X
    like: b'1733.0,36.0,1884.7,30.2,34.0,34.2,34.0,0.0,34.0,32.3,32.0,2.0
    avg : The data as average over the last avg seconds; avg > 0
    """
    # NOTE: avg is currenlty ignored; CPM is the minute average of CPS anyway

    global index

    fncname = "getDataCSV: "

    index += 1

    start = time.time()
    CPM    = getCPM()
    CPS    = getCPS()
    CPM1st = getCPM1st()
    CPS1st = getCPS1st()
    CPM2nd = getCPM2nd()
    CPS2nd = getCPS2nd()

    lastrec = "{:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}".format(
                CPM, CPS,
                CPM1st, CPS1st,
                CPM2nd, CPS2nd,
                NAN, NAN,
                NAN, NAN, NAN, NAN
            )
    stop = time.time()

    duration = 1000 * (stop - start) # ms
    cpxlist = (index, stime(), CPM, CPS, CPM1st, CPS1st, CPM2nd, CPS2nd, duration)
    writeLogfileAppend("{:7d}, {:19s}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}\n".format(*cpxlist))

    return bytes(lastrec, "UTF-8") # no comma at the end!


############################################################################
# Hardware functions for GMC devices  ######################################
############################################################################

def initGMC():

    global ser, nbytes, GMCport, GMCbaudrate, GMCtimeout

    fncname = "initGMC: "
    GMC_counter_version = "Undefined"

    # getting USB-to-Serial ports
    if GMCport != "auto":
        # GMCport was set manually; do not change
        pass
    else:
        # GMCport is "auto". Find the ports on this system
        dprint ("Searching for USB-to-Serial Ports - found on this system:")
        GMCports =  serial.tools.list_ports.comports()
        if len(GMCports) == 0:
            dprint("No USB-to-Serial Ports found on this system - Cannot run without one. Exiting.")
            return "Failure"

        # check for a GMC port with chip CH340
        foundport = False
        for port in GMCports :
            dprint ("   " + str(port))
            if  port.vid == 0x1a86 and port.pid == 0x7523:
                foundport = True
                GMCport = port.device
                break
        if not foundport:
            dprint("No GMC Ports found on this system - Cannot run without one. Exiting.")
            return "Failure"
    # dprint("   Selected Port: " + GMCport)
    print()


    # setting baudrate
    if GMCbaudrate != "auto":
        # GMCbaudrate was set manually; do not change
        pass
    else:
        # GMCbaudrate is "auto". Find the highest baudrate
        testbr = (115200, 57600)
        for br in testbr:
            try:
                testser = serial.Serial(GMCport, br, timeout=3)
                # print("testser: ", testser)
                bwrt = testser.write(b'<GETVER>>')
                trec = testser.read(14) # may leave bytes in the pipeline, if GETVER has
                                        # more than 14 bytes as may happen in newer counters
                # print("rec: ", rec)

                while True:
                    cnt = testser.in_waiting
                    if cnt == 0: break
                    trec += testser.read(cnt)
                    time.sleep(0.1)
                testser.close()
                # print("rec: ", rec)

                if trec.startswith(b"GMC"):
                    GMCbaudrate = br
                    # dprint("Baudrate: Success with {}".format(GMCbaudrate))
                    # gglobs.GMCDeviceDetected = rec.decode("UTF-8")
                    GMC_counter_version = trec.decode("UTF-8")
                    break

            except Exception as e:
                errmessage1 = fncname + "ERROR: Serial communication error on finding baudrate"
                exceptPrint(e, errmessage1)
                baudrate = None
                break

    # dprint("   Selected Baudrate: {}".format(GMCbaudrate))

    if GMCbaudrate == "auto":
        dprint("Could not establish communication with a counter. Is it connected? Will exit.")
        return "Failure"

    # timeout setting
    if GMCtimeout != "auto":
        # GMCtimeout was set manually; do not change
        pass
    else:
        # GMCtimeout is "auto". Set the timeout
        GMCtimeout = 3
    # dprint("   Selected Timeout: {}".format(GMCtimeout))


    # open the serial port with selected settings
    ser = serial.Serial(GMCport, GMCbaudrate, timeout=GMCtimeout)
    # dprint("ser: ", ser)

    if   "GMC-3"            in GMC_counter_version:   nbytes  = 2
    elif "GMC-500Re 1."     in GMC_counter_version:   nbytes  = 2    # perhaps Mike is only user
    elif "GMC-5"            in GMC_counter_version:   nbytes  = 4    # all 500+ and 510
    elif "GMC-6"            in GMC_counter_version:   nbytes  = 4    # all 500
    else:                                             nbytes  = 4    # everything else

    dprint("GMC Settings:")
    dprint("   {:50s} : {}".format("GMC Counter Version"         , GMC_counter_version))
    dprint("   {:50s} : {}".format("GMC Serial Port"             , GMCport))
    dprint("   {:50s} : {}".format("GMC Serial Baudrate"         , GMCbaudrate))
    dprint("   {:50s} : {}".format("GMC Serial Timeout (sec)"    , GMCtimeout))
    dprint("   {:50s} : {}".format("GMC Counter Byte Counts"     , nbytes))
    dprint("   {:50s} : {}".format("GMC Log file"                , GMClogfile))
    print()

    # clear logfile and write
    msg  = "# Log file created with: '{}', Version: {}\n".format(__script__, __version__)
    msg += "# Python Version: {}\n".format(sys.version.replace('\n', ""))
    msg += "# Index,            DateTime,    CPM,    CPS, CPM1st, CPM2nd, CPS1st, CPS2nd, Duration[ms]\n"
    writeLogfileWrite(msg)

    return "Ok"


def getCPM():
    """the normal CPM call; might get CPM as sum of both tubes' CPM"""

    return getGMC_Data(wcommand=b'<GETCPM>>', rlength=nbytes)


def getCPS():
    """the normal CPS call; might be the sum of High- and Low- sensitivity tube"""

    return getGMC_Data(wcommand=b'<GETCPS>>', rlength=nbytes, maskHighBit=True)


def getCPM1st():
    """get CPM from High Sensitivity tube; that should be the 'normal' tube"""

    return getGMC_Data(wcommand=b'<GETCPML>>', rlength=nbytes)


def getCPS1st():
    """get CPS from High Sensitivity tube; that should be the 'normal' tube"""

    return getGMC_Data(wcommand=b'<GETCPSL>>', rlength=nbytes, maskHighBit=True)


def getCPM2nd():
    """get CPM from Low Sensitivity tube; that should be the 2nd tube in the 500+"""

    return getGMC_Data(wcommand=b'<GETCPMH>>', rlength=nbytes)


def getCPS2nd():
    """get CPS from Low Sensitivity tube; that should be the 2nd tube in the 500+"""

    return getGMC_Data(wcommand=b'<GETCPSH>>', rlength=nbytes, maskHighBit=True)


def getGMC_Data(wcommand, rlength, maskHighBit=False):
    """Write to and read from device and convert to value; print, and return value"""

    fncname = "getGMC_Data: "

    try:
        bwrt = ser.write(wcommand)  # returns bytes-written of type int
        srec = ser.read(rlength)    # returns srec of type bytes
        # dprint(fncname + "srec: ", srec)
    except Exception as e:
        exceptPrint(e, fncname)
        msg = "# EXCEPTION: " + fncname + str(e) + "\n"
        writeLogfileAppend(msg)
        return NAN

    if len(srec) == nbytes:     # ok, got n bytes as expected
        if    nbytes == 4:
            value = ((srec[0]<< 8 | srec[1]) << 8 | srec[2]) << 8 | srec[3]
        elif  nbytes == 2:
            value = srec[0] << 8 | srec[1]
            if maskHighBit :    value = value & 0x3fff   # mask out high bits, as for CPS* calls on 300 series counters
        else:
            value = NAN         # should never happen

    else: # bytes missing or too many
        msg = "# ERROR in byte count, got {} bytes, expected {}!".format(len(srec), nbytes)
        dprint(msg)
        writeLogfileAppend(msg + "\n")
        value = NAN

    dprint("   " + fncname, "wcommand:{:13s}, rlength:{:1d}, maskHighBit:{:5s}, srec:{:20s}, value:{:0.3f}".format(str(wcommand), rlength, str(maskHighBit), str(srec), value))

    return value


def getExtraByte():
    """read single bytes until no further bytes coming, and return combined bytes"""

    xrec = b""
    try: # failed when called from 2nd instance of GeigerLog; just to avoid error
        bytesWaiting = ser.in_waiting
    except:
        bytesWaiting = 0

    if bytesWaiting == 0:
        # dprint("getExtraByte: No extra bytes waiting for reading")
        pass
    else:
        # dprint("getExtraByte: Bytes waiting: {}".format(bytesWaiting))
        while True:                # read single byte until nothing is returned
            x = ser.read(1)
            if len(x) == 0: break
            xrec += x
    # dprint("getExtraByte: xrec:", xrec)

    return xrec


def writeLogfileWrite(msg):
    """Erases the file content if the file exists, then writes msg to file"""

    if GMClogfile == "": return # no writing if GMClogfile is empty

    with open(GMClogfile, 'w') as log:
        log.write(msg)


def writeLogfileAppend(msg):
    """appends msg to the end of file content"""

    if GMClogfile == "": return # no writing if GMClogfile is empty

    with open(GMClogfile, 'a') as log:
        log.write(msg)


############################################################################
# End Hardware functions for GMC devices  ##################################
############################################################################

############################################################################
# Hardware functions for Raspi Pulse Counter  ##############################
############################################################################


def initPulse():

    global PulseCounts

    fncname                 = "initPulse: "
    Pulse_counter_version   = "Undefined" # not (yet) needed
    PulseCounts             = 0
    index                   = 0

    # import RPi.GPIO as GPIO     # install with: python -m pip install -U RPi.GPIO
    # # error when running on Desktop: RuntimeError: This module can only be run on a Raspberry Pi!

    # # from time import sleep
    # bcmpin = 17                 # bcm=17 ==> boardpin=11
    # GPIO.setmode(GPIO.BCM)
    # GPIO.setup(bcmpin, GPIO.IN, pull_up_down = GPIO.PUD_UP)
    # GPIO.add_event_detect(bcmpin, GPIO.FALLING, callback=incrementCounts)

    return "Ok"


def incrementCounts(channel):
    """increment Pulse counter"""

    global PulseCounts
    PulseCounts += 1


def getDataCSVPulse(avg):
    """returns data as a CSV list as bytes: M, S, M1, S1, M2, S2, M3, S3, T, P, H, X
    like: b'1733.0,36.0,1884.7,30.2,34.0,34.2,34.0,0.0,34.0,32.3,32.0,2.0
    avg : The data as average over the last avg seconds; avg > 0
    """
    # NOTE: avg is currenlty ignored; CPM is the minute average of CPS anyway

    global index

    fncname = "getDataCSV: "

    index += 1
    start  = time.time()
    CPS    = getPulseCPS()

    lastrec = "{:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}, {:0.3f}".format(
                NAN, CPS,
                NAN, NAN,
                NAN, NAN,
                NAN, NAN,
                NAN, NAN, NAN, NAN
            )
    stop = time.time()

    duration = 1000 * (stop - start) # ms
    CPM, CPSX, CPM1st, CPS1st, CPM2nd, CPS2nd = NAN, NAN, NAN, NAN, NAN, NAN
    cpxlist = (index, stime(), CPM, CPS, CPM1st, CPS1st, CPM2nd, CPS2nd, duration)
    writeLogfileAppend("{:7d}, {:19s}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}, {:6.2f}\n".format(*cpxlist))

    return bytes(lastrec, "UTF-8") # no comma at the end!


def getPulseCPS():
    """read counts and return as value"""

    global PulseCounts
    fncname = "getPulseCPS: "

    value       = PulseCounts
    PulseCounts = 0

    return value


############################################################################
# End Hardware functions for Raspi Pulse Counter  ##########################
############################################################################

def main():

    global __script__, hardware

    if sys.version_info[0] != 3:
        print("This software requires Python Version 3.")
        print("Your Python version is Version {}.{}".format(sys.version_info[0], sys.version_info[1]))
        print("Cannot continue, will exit.")
        return

    __script__ = os.path.basename(__file__)
    print("=" * 150)
    dprint("{:53s} : {}".format("Version of {}".format(__script__), __version__))
    dprint("{:53s} : {}".format("Version of Python ", sys.version.split(" ")[0]))
    print()

    # init the hardware
    # hardware = "GMC"
    hardware = "Pulse"

    if hardware == "GMC":       hardwareresponse = initGMC()
    elif hardware == "Pulse":   hardwareresponse = initPulse()
    dprint("Init {} Counter: {}".format(hardware, hardwareresponse))

    # init the WiFi Server
    if hardwareresponse == "Ok":
        WSresponse = initWiFiServer()
        dprint("Init WiFi Server: ", WSresponse)
    else:
        dprint("No connection to {} counter. Will exit.".format(hardware))
        return

    print()

    try:
        while True: time.sleep(100)
    except KeyboardInterrupt:
        print()
        terminateWiFiServer()
        dprint("Exiting WiFiServer")


if __name__ == '__main__':

    main()
    print()